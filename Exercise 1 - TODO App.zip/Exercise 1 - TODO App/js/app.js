var x=0;
function addToDo(){
    var text=$('#task-txt').val();
    if(text != ""){
    $("#task-txt").val("");
    var li = `<li id="${x}"> ${text} <button onclick="deleteToDo(${x})">Delete</button> </li>`;
    x+=1;
    $('#pending-list').append(li);
    $("#task-txt").focus();
}
else{
    alert("Please fill the field");
}
}

function deleteToDo(id){
    console.log("yes");
    $('#'+id).remove();
}
//execute function

function init(){

$('#add-task').click(addToDo);

$("#task-txt").keypress(function(e){
    console.log(e.key);
    if(e.key==="Enter"){
        addToDo();
    }
})
}

//when the broweser is finished rendering the HTML, execute it
window.onload=init;
