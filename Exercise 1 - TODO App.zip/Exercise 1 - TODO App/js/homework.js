let data = [
    {
        name:"Mark",
        age: 30
    },
    {
        name:"Mark",
        age: 30
    },
    {
        name:"Mark",
        age: 30
    },
    {
        name:"Mark",
        age: 30
    },
    {
        name:"Mark",
        age: 30
    },
    {
        name:"Mark",
        age: 30
    }
];

console.table(data);

//design a set of function to do the following
//Who (name,age) display who is the oldest
//who (name,age) who is the youngest
//Sum all of the ages and display